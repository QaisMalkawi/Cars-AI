using UnityEngine;

namespace HurkyUtils
{
    public class Wheel : MonoBehaviour
    {
        [SerializeField] WheelCollider wheelCollider;//the collider that the mesh will follow
        [SerializeField] float driftThrushold;//the difference in speed between the wheels and the body to trigger smoke
        [SerializeField] ParticleSystem smoke;//the smoke effect

        float wheelSpeed;//the speed of the wheel
        float carSpeed;//the speed of the car

        void Update()
        {
            //updating the mesh of the wheel
            Vector3 pos;
            Quaternion rot;
            wheelCollider.GetWorldPose(out pos, out rot);
            transform.position = pos;
            transform.rotation = rot;

            //getting the wheel speed
            wheelSpeed = GetWheelSpeed(wheelCollider);

            //getting the car speed
            carSpeed = transform.root.GetComponent<CarMotorAI>().GetCarSpeed();

            //emitting smoke if the wheel is isn't moving as quick as the car(drifting/skiding) with headspace.
            if ((Mathf.Abs(wheelSpeed - carSpeed) >= (driftThrushold * Mathf.Clamp(carSpeed / 10, 1f, 10f)) || Mathf.Abs(transform.root.GetComponent<Rigidbody>().angularVelocity.y) >= driftThrushold / 2) && wheelCollider.isGrounded)
            {
                smoke.emissionRate = Mathf.Clamp(Mathf.Abs(wheelSpeed) * Mathf.Abs(wheelSpeed - carSpeed), 1f, 2500f);
            }
            else
            {
                smoke.emissionRate = 0;
            }

        }
        float GetWheelSpeed(WheelCollider wheel)
        {
            //returns the speed that the wheel ismoving
            float Speed = 2 * Mathf.PI * wheel.radius * wheel.rpm * 6 / 100;
            return Speed;
        }
    }
}