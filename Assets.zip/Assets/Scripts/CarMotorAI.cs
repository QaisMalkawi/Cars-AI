using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace HurkyUtils
{
    [RequireComponent(typeof(Rigidbody))]
    public class CarMotorAI : MonoBehaviour
    {
        [SerializeField] Transform CoM;//the center of mass for the car (helps with stabiltiy)
        [SerializeField] Waypoint target;//the target waypoint for the AI

        [SerializeField] WheelCollider[] frontWheels;//aka steering wheels
        [SerializeField] WheelCollider[] drivingWheels;//aka driving wheels

        [SerializeField] float maxTorque = 160f;//the amount of torque that is applied on each wheel
        [SerializeField] float maxSpeed = 100f;//car max speed
        [SerializeField] float maxReverseDistane = 10f;//the max distace to determine weather to reverse to the target or rotate towerds it without reversing

        [SerializeField] float maxSteerAngle = 40f;//the max angle for steering
        [SerializeField] float steerSpeed = 3f;//how quick does the steering tern

        [SerializeField] float brakeForce = 1000f;//the max force of brakes

        [SerializeField] bool playerDiven = false;//toggles the AI on/off and switching to manual driving

        [SerializeField] Sensor[] sensors;//the sensors for the AI

        private float reachDistane;//the distance to consider that the car reached the waypoint
        private float bodySpeed;//the velocity of the rigidbody
        private float steerAngle;//the current angle of the steering
        private float brakesValue = 0;//the current value for the brakes
        private Rigidbody carRB;//the rigidbody component for the car
        private bool avoiding;//weather the sensors are detecting obstacles or not


        void Start()
        {
            //getting the RigidBody for the car, and applying the center of mass if avilable
            carRB = GetComponent<Rigidbody>();
            if (CoM != null)
                carRB.centerOfMass = CoM.localPosition;
            reachDistane = target.area;

            if(target == null){
                target = FindObjectOfType<Waypoint>();
                if (target == null)
                {
                    Debug.LogError("You need to create a waypoint.");
                }
            }
        }

        void Update()
        {
            if(Input.GetKeyDown(KeyCode.KeypadPlus))
            {
                Time.timeScale = Mathf.Clamp(Time.timeScale + 0.1f, 0f, 5f);
            }
            else if (Input.GetKeyDown(KeyCode.KeypadMinus))
            {
                Time.timeScale = Mathf.Clamp(Time.timeScale - 0.1f, 0f, 5f);
            }
            //getting the vectors towards the target(x:left/right, y:up/down, z:forward/backward), and normalizing the values (0 - 1)
            Vector3 driveData = transform.InverseTransformPoint(target.transform.position);
            driveData /= driveData.magnitude;

            //getting the values in-case of playerDriven is on
            float steerInput = Input.GetAxis("Horizontal");
            float thrInput = Input.GetAxis("Vertical");
            float brakesInput = Input.GetKey(KeyCode.Space) ? 1 : 0;

            //applying the values and deciding if the player has controlll or not depending on playerDriven toggle
            float steerValue = playerDiven ? steerInput : driveData.x;
            float thrValue = playerDiven ? thrInput : driveData.z;

            //checking if the car has reached the target waypoint or not, in case of the AI taking controll. 
            if (target != null && Vector3.Distance(target.transform.position, transform.position) <= reachDistane && !playerDiven)
                nextWayPoint();

            //updating the speed of the car using the rigidbody velocity
            bodySpeed = new Vector3(carRB.velocity.x, 0, carRB.velocity.z).magnitude * 3.6f;

            //using sensors if the player isn't taking controll
            if (!playerDiven)
                Sensors();

            //using driveData resaults if sensors arn't detecting obstacles and taking controll
            if (!avoiding)
            {
                Drive(thrValue);
                Steer(steerValue, thrValue);
            }

            //applying brakes
            Brake(playerDiven ? brakesInput : brakesValue);
        }

        void Steer(float angle, float dir)
        {
            //turning normalized value of steering to an actual angle
            float appangle = angle * maxSteerAngle;

            //checking if the distance is inside the "maxReverseDistane" range to determine whether to reverse to the waypoint or drive around and point towards it
            if (!playerDiven && maxReverseDistane <= Vector3.Distance(transform.position, target.transform.position) && dir <= 0)
            {
                if (angle > 0)
                {
                    appangle += maxSteerAngle / 2;
                }
                else
                {
                    appangle -= maxSteerAngle / 2;
                }
            }

            //rotating the wheels smoothly to the chosen angle
            foreach (WheelCollider wheel in frontWheels)
            {
                wheel.steerAngle = Mathf.Lerp(wheel.steerAngle, Mathf.Clamp(appangle, -maxSteerAngle, maxSteerAngle), Time.deltaTime * steerSpeed);
            }
        }

        void Drive(float throutle)
        {
            //stop providing the wheels with torque if the speed is over the max speed
            if (bodySpeed >= maxSpeed)
                return;

            //completing the chosen condition in line 91
            if (!playerDiven && maxReverseDistane <= Vector3.Distance(transform.position, target.transform.position))
                throutle = Mathf.Abs(throutle);

            //applying the torque
            foreach (WheelCollider wheel in drivingWheels)
            {
                wheel.motorTorque = maxTorque * throutle * drivingWheels.Length;
            }
        }

        void Brake(float force)
        {
            //applying brakes
            foreach (WheelCollider wheel in drivingWheels)
            {
                wheel.brakeTorque = force * brakeForce;
            }
        }

        void nextWayPoint()
        {
            //finding the next waypoint
            target = target.nextWayPoint;
            reachDistane = target.area;
        }

        public float GetCarSpeed()
        {
            //bodySpeed getter for public use
            return this.bodySpeed;
        }

        void Sensors()
        {
            //stores the hit data
            RaycastHit hit;

            //initializing new data in case of sensors detecting obstacles
            float thr = 0;
            float steer = 0;
            brakesValue = 0;
            avoiding = false;

            //looping through each sensor and reading data
            foreach (Sensor sensor in sensors)
            {
                //assigning the start point for the ray
                Vector3 startPosition = transform.position;
                startPosition += transform.right * sensor.sensorOffset.x;
                startPosition += transform.up * sensor.sensorOffset.y;
                startPosition += transform.forward * sensor.sensorOffset.z;

                //shooting the ray with the Characteristics determined by the sensor variables
                if (Physics.Raycast(startPosition, Quaternion.AngleAxis(sensor.sensorAngle, transform.up) * transform.forward, out hit, sensor.sensorLength, sensor.detectedLayers))
                {
                    //drawing the ray if hit occured
                    Debug.DrawLine(startPosition, hit.point, sensor.debugColor);

                    //checking if hitNormalSteer is enabled and applying the suitable resaults for the steering
                    if (sensor.hitNormalSteer)
                    {
                        steer += hit.normal.x * sensor.hitNormalSteerMultiplier;
                    }
                    else
                    {
                        steer += sensor.steer;
                    }

                    //applying the Characteristics of the sensor on the data
                    thr += sensor.throutle;
                    thr = Mathf.Clamp(thr, -1, 1);
                    brakesValue += sensor.brakes;

                    //toggling the sensors on to take controll and avoid the obstacles.
                    avoiding = true;
                }
            }

            //checking if the sensors are taking controll
            if (avoiding)
            { 
                //applying data
                foreach (WheelCollider wheel in drivingWheels)
                {
                    wheel.motorTorque = maxTorque * thr * drivingWheels.Length;
                }
                foreach (WheelCollider wheel in frontWheels)
                {
                    wheel.steerAngle = Mathf.Lerp(wheel.steerAngle, Mathf.Clamp(steer * maxSteerAngle, -maxSteerAngle, maxSteerAngle) * (thr > 0 ? 1 : -1), Time.deltaTime * steerSpeed);
                }
            }
        }

        [System.Serializable]
        struct Sensor
        {
            //the name of the sensor, only for debugging and understanding reasons.
            [SerializeField] string name;

            //the color of the drawn line for the hit occurance
            public Color debugColor;

            [Header("")]
            public float sensorLength;//the range of the sensor detecting
            public Vector3 sensorOffset;//the position of the sensor on the car
            public float sensorAngle;//the angle of the sensor
            public LayerMask detectedLayers;//the layers that the sensor detects

            [Header("Effects:")]
            [Range(-1, 1)] public float throutle;//the amount of throutle to add in case of detect obstacle
            [Range(0, 1)] public float brakes;//the amount of brakes to add in case of detect obstacle
            [Range(-1, 1)] public float steer;//the amount of steer to add in case of detect obstacle

            [Header("Hit normal Overwrite steer:")]
            public bool hitNormalSteer;//determines wiether to use the hit normal or the assigned steer variable
            public float hitNormalSteerMultiplier;//multiplies the hit normal output
        }
    }
}
