using UnityEngine;

namespace HurkyUtils
{
    public class Waypoint : MonoBehaviour
    {
        public Waypoint previousWayPoint;//the Waypoint before this Waypoint
        public Waypoint nextWayPoint;//the Waypoint after this Waypoint
        public float area = 5;//the area that this waypoint covers.

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.green;
            Gizmos.DrawWireSphere(transform.position, area);
        }
    }
}
