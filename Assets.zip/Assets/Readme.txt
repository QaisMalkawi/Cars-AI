Description:
'''
this product will help you creating an easy to use vehicles AI,
With the ability to make it with your targeted accuracy
with an easy to use and fully described interface.

This product also includes a waypoint-based road building system
to help you creating YOUR paths for YOUR AI.
'''

Features:
'''
-CarAI: with a Fully Customizable  Charactarestic (Vehicle Torque, Vehicle Max Speed, Vehicle Steering Angle, Vehicle Sensors, ...) 
		with the ability to toggle AI on and off.

-Car Sensors: you can add as many Sensors as you want for your vehicle,
			  and decide what you want them to do real-Time.

-Path building System: you can use to create YOUR own path
					   real-Time with a waypoint-based system.
'''

Disclaimer:
'''
Purchasing this product gives you the ability to use it as you want,
including using it in a (game - film - tutorial),
but you are not allowed to share the asset for free or re-puplish it for your own profit.

Car model:
	https://www.cgtrader.com/free-3d-models/car/antique/triumph-dolomite-sprint
'''

Contact:
	malkawiareej1978e@gmail.com


Patreon:
	https://www.patreon.com/QaisMlk
