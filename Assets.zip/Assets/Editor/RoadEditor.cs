using UnityEngine;
using UnityEditor;
using HurkyUtils;

[InitializeOnLoad()]
public class RoadEditor : MonoBehaviour
{
    [DrawGizmo(GizmoType.NonSelected | GizmoType.Selected | GizmoType.Pickable)]
    public static void OnDrawSceneGizmo(Waypoint waypoint, GizmoType gizmoType)
    {
        if ((gizmoType & GizmoType.Selected) != 0)
        {
            Gizmos.color = Color.yellow;
        }
        else
        {
            Gizmos.color = Color.yellow * 0.5f;

        }
        Gizmos.DrawSphere(waypoint.transform.position, 0.1f);

        Gizmos.color = Color.white;
        if (waypoint.nextWayPoint != null) 
        {
            Gizmos.DrawLine(waypoint.transform.position, waypoint.nextWayPoint.transform.position);
        }
        else
        {
            Gizmos.color = Color.red;
            Gizmos.DrawSphere(waypoint.transform.position, 0.2f);
        }
        if(waypoint.previousWayPoint == null){
            Gizmos.color = Color.green;
            Gizmos.DrawSphere(waypoint.transform.position, 0.2f);
        }
    }
}
